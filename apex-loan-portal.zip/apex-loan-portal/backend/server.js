const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'APEX Loan API Running' });
});

app.post('/api/loan/apply', (req, res) => {
  res.json({
    success: true,
    applicationId: 'AFS2026-0001',
    data: req.body
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
