CREATE TABLE loan_applications (
    id SERIAL PRIMARY KEY,
    application_id VARCHAR(20) UNIQUE,
    loan_type VARCHAR(50),
    loan_amount NUMERIC,
    full_name VARCHAR(100),
    contact_no VARCHAR(20),
    email_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE lenders (
    id SERIAL PRIMARY KEY,
    lender_name VARCHAR(100),
    min_cibil INT,
    min_salary NUMERIC,
    min_turnover NUMERIC
);

CREATE TABLE advisors (
    id SERIAL PRIMARY KEY,
    advisor_code VARCHAR(20),
    advisor_name VARCHAR(100),
    mobile VARCHAR(20),
    approved BOOLEAN DEFAULT FALSE
);

CREATE TABLE commissions (
    id SERIAL PRIMARY KEY,
    application_id VARCHAR(20),
    advisor_code VARCHAR(20),
    loan_amount NUMERIC,
    commission_percent NUMERIC,
    commission_amount NUMERIC,
    status VARCHAR(20) DEFAULT 'Pending'
);
