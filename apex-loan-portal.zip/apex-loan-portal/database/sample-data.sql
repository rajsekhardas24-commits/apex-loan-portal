INSERT INTO lenders (lender_name, min_cibil, min_salary, min_turnover)
VALUES
('HDFC Bank', 700, 25000, 1000000),
('ICICI Bank', 720, 30000, 1500000),
('Bajaj Finance', 680, 20000, 800000);
