import React from 'react';
import ReactDOM from 'react-dom/client';

function App() {
  return (
    <div style={{fontFamily:'Arial',padding:'20px'}}>
      <h1>APEX Financial Solutions</h1>
      <p>Loan Management Portal</p>
      <h2>Public Loan Application</h2>
      <form>
        <input placeholder="Full Name" /><br/><br/>
        <input placeholder="Contact Number" /><br/><br/>
        <input placeholder="Loan Amount" /><br/><br/>
        <button type="submit">Submit Application</button>
      </form>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
