# APEX Financial Solutions Loan Management Portal

## Frontend Deployment (Vercel)
1. Upload frontend folder
2. Build command: npm run build
3. Output directory: dist

## Backend Deployment (Render)
1. Upload backend folder
2. Build command: npm install
3. Start command: npm start

## Database
Import database/schema.sql into PostgreSQL.
